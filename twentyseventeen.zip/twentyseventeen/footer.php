<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.2
 */

?>

		</div><!-- #content -->
<div class="wrapper">
	<div class="row">
		<div class="col-sm-6 footer">
			<h3>Adresse:</h3>
			<p>
				Mejlgade 57
				<br>
				8000 Aarhus C
			</p>
		</div>
		
		<div class="col-sm-6 footer">
			<h3>Kontakt:</h3>
			<p>
				Tlf: 41 41 11 03
				<br>
				E-mail: Mahalo@info.dk
			</p>
		</div>
	</div>	
	<div class="row">
		<div class="col-sm-12 footer">
			<h3>Åbningstider:</h3>
			<p>
				Mandag - Torsdag
				<br>
				11:30 - 20:00
			</p>
			<p>
				Fredag - Lørdag
				<br>
				11:30 - 21:00
			</p>
			<p>
				Søndag
				<br>
				14:00 - 20:00
			</p>
		</div>
		
		<div class="col-sm-12 footer some-buttons-box-footer">
			<img src="<?php get_template_directory().'/img/fb-icon-footer.png' ?>" class="some-button-footer">
			<img src="img/insta-icon-footer.png" class="some-button-footer">
		</div>
	</div>
</div>
	</div><!-- .site-content-contain -->
</div><!-- #page -->
<?php wp_footer(); ?>
</body>
</html>
