<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header('menu'); ?>

<div class="bg-image">
<div class="wrapper">
<h1 class="title">Menu</h1>

<div class="col-sm-12 menu-item">
	<h2 class="menuside">TUNA TURNER</h2>
	<p>Ris · Wakame <br>
	Tun · Rødløg · Sesam · Spicy Miso Mayo <br>
	Ananas · Jalapeño · Avocado · Forårsløg <br>
	Urter · Sesam · Rogn · Sesam-mayo</p>
	<p class="price"><span class="price-size">Alm.</span> 85 kr <span class="price-size">Stor.</span> 105 kr </p>
</div>

<div class="col-sm-2 line">
		<hr>
</div>

<div class="menu-item">
	<h2 class="menuside">SALMON DIAZ</h2>
	<p>Ris · Wakame <br>
	Laks · Rødløg · Edamame · Sesam · Yuzu Ponzu <br>
	Agurk · Forårsløg <br>
	Radise · Sesam · Siracha-mayp</p>
	<p class="price"><span class="price-size">Alm.</span> 85 kr <span class="price-size">Stor.</span> 105 kr </p>
</div>

<div class="col-sm-2 line">
		<hr>
</div>

<div class="menu-item">
	<h2 class="menuside">CRAY CRAY</h2>
	<p>Ris · Spidskål <br>
	Krebsehaler · Rødløg · Urter · Sesam · Yuzu Ponzu <br>
	Ananas · Edamame · Jalapeño · Granatæble <br>
	Radise · Blomst · Siracha-mayo</p>
	<p class="price"><span class="price-size">Alm.</span> 80 kr <span class="price-size">Stor.</span> 100 kr </p>
</div>

<div class="col-sm-2 line">
		<hr>
</div>

<div class="menu-item">
	<h2 class="menuside">BIG SHRIMPIN</h2>
	<p>Ris · Spidskål <br>
	Rejer · Rødløg · Yozu Ponzu<br>
	Cherrytomat · Forårsløg · Avocado · Urter <br>
	Radise · Blomst · Granatæble · Estragon-mayo</p>
	<p class="price"><span class="price-size">Alm.</span> 85 kr <span class="price-size">Stor.</span> 105 kr </p>
</div>

<div class="col-sm-2 line">
		<hr>
</div>

<div class="menu-item">
	<h2 class="menuside">TUNAMI</h2>
	<p>Ris · Wakame <br>
	Tun · Rødløg · Syltede rødløg · Teriyaki <br>
	Ananas · Forårsløg · Avocado <br>
	Radise · Blomst · Siracha-Mayo</p>
	<p class="price"><span class="price-size">Alm.</span> 85 kr <span class="price-size">Stor.</span> 105 kr </p>
</div>

<div class="col-sm-2 line">
		<hr>
</div>

<div class="menu-item">
	<h2 class="menuside">SHAKA MEATLESS</h2>
	<p>Ris · Spidskål <br>
	Tofu · Rødløg · Spicy Miso soya <br>
	Edamame · Forårsløg · Avocado <br>
	Radise · Granatæble · Blomster · Goma-Sauce</p>
	<p class="price"><span class="price-size">Alm.</span> 75 kr <span class="price-size">Stor.</span> 95 kr </p>
</div>

<div class="col-sm-2 line">
		<hr>
</div>

<div class="menu-item">
	<h2 class="menuside">PICK YOUR POKE</h2>
	<p>1. Base <br>
	2. Fyld <br>
	3. Topping <br>
	4. Finish</p>
	<p class="price"><span class="price-size">Alm.</span> 95 kr <span class="price-size">Stor.</span> 115 kr </p>
</div>

<div class="col-sm-2 line">
		<hr>
</div>

<div class="menu-item">
	<h2 class="menuside">DRIKKEVARER</h2>
	<p>Vand <br>
	Egekilde <br>
	Sodavand <br>
	Jarritos
	</p>
</div>

<!-- Knap til at bestille mad fra den eksterne deviverit side -->
<div class="button-box">
<a href="https://mahalopoke.deliverit.dk/" class="test" target="_blank">
<button class="order-button">Bestil Takeaway</button>
</a>
</div>

</div>
</div>
<?php get_footer(); ?>
