<?php get_header() ?>


<div class="bg-image">
<div class="wrapper-home">
	<div class="row">
		<div class="col-sm-12 homecontentbox">
			<h1 class="front-title">
				Aloha!
			</h1>
			<p>
				I februar 2018 åbnede Aarhus første Poke Bowl shop i Mejlgade. Vi har glædet os til at byde jer på noget, som vi er stensikre på vil falde i god jord - både hos jer der kender poke og hos jer der savner at prøve noget nyt.  
			</p>
			<p>
				Poke, som udtales [po-kæi] og groft oversat betyder ”at skære”, har længe eksisteret på Hawaii, hvor Poke Bowls som vi kender det i dag, blev rigtig populært i 1970’erne. På Hawaii er Poke ligeså normalt som franske hotdogs er for os, og du finder det derfor alle steder.  
			</p>
			
			<!-- Teksten inden i textarea div'en er som udgangspunkt skjult -->
			<div id="textarea">
			<p>
				Poke er blevet nævnt som ”Den næste generation af sushi”, og har allerede vundet indpas flere steder i verden, og det forstår vi godt; 
			</p>
			
			<p>
				Poke Bowls repræsenterer mange af de ting vi allerbedst kan lide: lækker mad, hvor der er kræset for detaljerne, som alligevel er helt afslappet og uprætentiøst. Frisk fisk, marineret med masser af smag, dampede ris og grønt og frugt eller sprødt, sammensat på en måde så alting går op i en højere enhed og smager af solskin.  
			</p>
			<p>
				Vi brænder for at lave Poke. Vi har brugt lang tid og mange kræfter på at kreere marinader og dressinger, og ligeså lang tid på at sammensætte de enkelte bowls på en måde så alting er lige præcis som det skal være. Vi går ikke på kompromis med kvaliteten, og vi får derfor hver dag frisk frugt og grønt samt fisk leveret til døren. Nyd den i vores flotte lyse lokale eller tag den to-go.  
			</p>
			<p>
				Vi glæder os til at introducere jer allesammen for vores hjertebarn, Århus’ første pokebar – Mahalo. 
			</p>
			<p>
				#SmagenAfHawaii
			</p>
		</div>
		<!-- funktion til at vise og skjule teksten i textarea div'en -->
			<ul class="controls">
    		<li class="show"><a href="#textarea" class="readmorecolor">Læs mere</a></li>
    		<li class="hide"><a href="#" class="readmorecolor">Skjul</a></li>
			</ul>
		</div>
</div>
</div>

        <!-- billede der skal illustrere, hvordan et instagram widget kunne se ud på siden -->
		<div class="insta-color">
			<h2 class="insta">
				Følg med på vores insta!
			</h2>
			<img src="img/mahalo-insta.png" alt="Demo billede for instagram plugin">
		</div>
	</div>
</div>
</div>	
	
	


<?php get_footer() ?>