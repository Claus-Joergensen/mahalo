<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header('plakater'); ?>

<div class="bg-image">
<div class="wrapper">
<h1 class="title">Plakater</h1>

<p>
	Tid til at peppe dit hjem lidt op? 
</p>
<p>
	Vores plakater bringer solen og Hawaii hjem i din stue, og findes i tre lækre varianter.  
</p>
<p>	
	Kunstneren bag plakaterne hedder Rasmus Boesen. Han er en god ven af Mahalo og har specielt designet kunsten, som vi har glæde af. 
</p>
<p>
	Send os en besked for at bestille - så kan du inden længe hente et lille stykke solskin i vores biks.
</p>
</div>

<!-- shortcode der implementerer galleriet fra foogallery plugin'et i wordpress -->
<?php echo do_shortcode('[foogallery id="16"]'); ?>

<div class="wrapper">
<div class="formbox">
<!-- shortcode der implementerer kontakt formen fra plugin'et i wordpress -->
<?php echo do_shortcode('[contact-form-7 id="101" title="Contact form 1"]'); ?>
</div>
</div>
</div>

<?php get_footer(); ?>
